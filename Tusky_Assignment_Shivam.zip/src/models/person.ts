export interface Person {
    name: string;
    id: number;
}